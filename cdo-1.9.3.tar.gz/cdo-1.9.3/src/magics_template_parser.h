#ifndef MAGICS_TEMPLATE_PARSER_HH
#define MAGICS_TEMPLATE_PARSER_HH

int magics_template_parser( void *node );

int SetMagicsParameterValue( const char *param_name, const char *param_type, const char *param_value );

#endif
