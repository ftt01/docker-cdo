#include "constants.h"

double PlanetRD      = C_EARTH_RD;
double PlanetRadius  = C_EARTH_RADIUS;
double PlanetGrav    = C_EARTH_GRAV;
